create procedure addDepty()
BEGIN

declare i int default 71; 

while i<90 DO

  insert into t_depty (deptno,dname,loc) values(i,CONCAT('部门',i),i);

  set i = i + 1;

end while;

end;

