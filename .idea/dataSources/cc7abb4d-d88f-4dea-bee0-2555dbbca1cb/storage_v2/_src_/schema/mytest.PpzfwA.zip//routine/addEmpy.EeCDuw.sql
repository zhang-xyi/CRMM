create procedure addEmpy()
BEGIN

declare i int default 41; 

while i < 90 DO

  insert into t_empy (EMPNO, ENAME, GENDER,JOB, MGR, HIREDATE, SAL,COMM, DEPTNO)
    values (i,i,'男','职员', 7698, null,2200,300, i);
  set i = i + 1;

end while;

end;

